#!/usr/bin/env python3
from brain_games.even_numbers import quest

def main():
    print('Welcome to the Brain Games!')
    quest()

if __name__ == '__main__':
    main()

