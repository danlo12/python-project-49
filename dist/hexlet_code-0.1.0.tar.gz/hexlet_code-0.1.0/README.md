### Hexlet tests and linter status:
[![Actions Status](https://github.com/danlo12/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/danlo12/python-project-49/actions)