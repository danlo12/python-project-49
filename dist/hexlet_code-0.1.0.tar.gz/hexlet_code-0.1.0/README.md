### Hexlet tests and linter status:
[![Actions Status](https://github.com/danlo12/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/danlo12/python-project-49/actions)
<a href="https://codeclimate.com/github/danlo12/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/976672c09d5d93cda900/maintainability" /></a>

step 5

https://asciinema.org/a/uRoFRgp33wfvwXSgt7sXHNf9F

step 6

https://asciinema.org/a/clMAsl1e55DAgGJ2zTqu2nfD1

step 7

https://asciinema.org/a/9AbyzIw27XMxqE5Wv7cbzeczL

step 8

https://asciinema.org/a/zog4Vzzz22Q3WZXc8dyqvgYb5

step 9

https://asciinema.org/a/rRwaJMIm4qjaaNG7kFimcGMQR
